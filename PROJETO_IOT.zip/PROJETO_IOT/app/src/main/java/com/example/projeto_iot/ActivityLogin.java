package com.example.projeto_iot;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;

import java.text.BreakIterator;

public class ActivityLogin extends AppCompatActivity {

    EditText usuario, senha;
    MaterialButton confirm;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_login);

        usuario = findViewById(R.id.user);
        senha = findViewById(R.id.senha);
        confirm = findViewById(R.id.loginbtn);

        usuario.setOnClickListener(view -> {
            BreakIterator UserEditText = null;
            BreakIterator SenhaEditText;
            String txt = "usuario: "+UserEditText.getText().toString()+" / senha: "+SenhaEditText.getText().toString();
            Toast.makeText(this, txt, Toast.LENGTH_SHORT).show();
        });

    }
