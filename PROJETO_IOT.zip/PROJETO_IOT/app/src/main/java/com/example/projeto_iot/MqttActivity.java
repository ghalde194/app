package com.example.projeto_iot;

import android.app.Activity;

public class MqttActivity extends Activity {
}
